# -*- coding: utf-8 -*-
"""apply_final.py - 把已验证的 _build_wrapper / _auto_generate_charts 装进项目文件。

做法(零风险):
1. 从 _lib_build_wrapper.py / _lib_auto_chart.py(独立、已端到端验证)读出函数源码
2. 在目标文件里: 删掉旧的 _build_wrapper / _auto_generate_charts, 插入新版本
3. run_experiment 原样保留, 仅幂等确保: 读 meta['data_table'] + 传 data_table=
不手写任何 wrapper 字符串拼接, 避免转义/缩进坑。
"""
import ast, inspect, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET = os.path.join(HERE, "app", "services", "experiment_engine.py")
LIB_BW = os.path.join(HERE, "_lib_build_wrapper.py")
LIB_AC = os.path.join(HERE, "_lib_auto_chart.py")
BAK = TARGET + ".final_bak"

# 读入两个独立模块, 提取其中函数的源码文本(用 inspect, 安全)
import importlib.util


def load_mod(path):
    spec = importlib.util.spec_from_file_location("_m_" + str(hash(path)), path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


mod_bw = load_mod(LIB_BW)
mod_ac = load_mod(LIB_AC)
SRC_BW = (inspect.getsource(mod_bw._serialize_data_table).rstrip()
           + "\n\n"
           + inspect.getsource(mod_bw._build_wrapper).lstrip())
SRC_AC = inspect.getsource(mod_ac._auto_generate_charts)

# 备份 + 读目标
if not os.path.exists(TARGET):
    raise SystemExit(f"目标不存在: {TARGET}  (请把本脚本放到 backend 目录运行)")
if os.path.exists(BAK):
    os.remove(BAK)
shutil.copy(TARGET, BAK)
print("[ok] 备份 ->", os.path.basename(BAK))

src = open(TARGET, encoding="utf-8", errors="ignore").read()
ast.parse(src)  # 原文件必须合法
lines = src.splitlines(keepends=True)
tree = ast.parse(src)

# 找三个函数的精确行区间 [start, end)  (用 ast 的 lineno/end_lineno)
funcs = {}
for node in tree.body:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        name = node.name
        start = node.lineno - 1
        end = getattr(node, "end_lineno", None)
        if end is None:
            # 兜底: 下一个顶层
            end = start + 1
            for j in range(start + 1, len(lines)):
                if lines[j].strip() and (lines[j][0] not in (" ", "\t")):
                    break
        funcs[name] = (start, int(end))

assert "_build_wrapper" in funcs, f"未找到 _build_wrapper, 只有 {list(funcs)}"
assert "_auto_generate_charts" in funcs, f"未找到 _auto_generate_charts, 只有 {list(funcs)}"
assert "run_experiment" in funcs, f"未找到 run_experiment, 只有 {list(funcs)}"

# 组装新文件:
#   head (到 _build_wrapper 之前) + 新_build_wrapper + 新_auto_chart + 原 run_experiment
head_end = funcs["_build_wrapper"][0]
head = "".join(lines[:head_end]).rstrip() + "\n\n"

run_start, run_end = funcs["run_experiment"]
run_text = "".join(lines[run_start:run_end])

# 幂等: 只把调用处的 _build_wrapper(...) 补上 data_table=data_table, 其余原文不动
call_old = "_build_wrapper(code, run_dir, charts_dir, generate_video)"
call_new = "_build_wrapper(code, run_dir, charts_dir, generate_video, data_table=data_table)"
if call_old in run_text:
    run_text = run_text.replace(call_old, call_new)
    print("[*] run_experiment: _build_wrapper 调用补 data_table=")
elif call_new in run_text:
    print("[*] run_experiment: 调用已传 data_table (跳过)")
else:
    print("[!] 警告: run_experiment 里没找到 _build_wrapper 调用, 请手动确认它传 data_table=")
    print("    当前 run_experiment 含 '_build_wrapper':", "_build_wrapper" in run_text)

# 拼接
new_src = head + SRC_BW.rstrip() + "\n\n" + SRC_AC.rstrip() + "\n\n" + run_text.rstrip() + "\n"

# 写前校验
ast.parse(new_src)
with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
    f.write(new_src)
ast.parse(open(TARGET, encoding="utf-8").read())  # 写后复校

print("[OK] 写入", TARGET, "| lines =", len(new_src.splitlines()))

# ---------- 自检 ----------
f = new_src
print("\n=== 结构自检 ===")
print("1) _serialize_data_table:", "_serialize_data_table" in f)
print("2) _DF_JSON 常量:", "_DF_JSON = " in f)
print("3) __run 定义:", "def __run(__code):" in f)
print("4) exec 显式传 df:", "exec(__code, _ns)" in f)
print("5) 图表真实版:", "无真实数据, 跳过(不造假)" in f)
print("6) _build_wrapper 接受 data_table:", "data_table=None) -> str:" in f)
print("7) 调用传 data_table:", "_build_wrapper(code, run_dir, charts_dir, generate_video, data_table=data_table)" in f)
print("8) 无残留 _resolve_df:", "def _resolve_df" not in f and "df = _resolve_df()" not in f)
print("9) SYNTAX OK:", True)

# ---------- 运行验证 ----------
print("\n=== 运行验证(_run.py 真实数据) ===")
for k in list(sys.modules.keys()):
    if "experiment_engine" in k:
        del sys.modules[k]
sys.path.insert(0, os.path.join(HERE, "app", "services"))
import experiment_engine as ee

td = tempfile.mkdtemp()
dt = {"columns": ["x", "y", "z"], "rows": [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]}
w = ee._build_wrapper(
    "print('DF:', type(df).__name__)\nif df is not None: print('COLS:', list(df.columns))",
    td, os.path.join(td, "charts"), False, data_table=dt)
rp = os.path.join(td, "_run.py")
open(rp, "w", encoding="utf-8").write(w)
r = subprocess.run([sys.executable, rp], capture_output=True, text=True)
print("STDOUT:", r.stdout.strip())
if r.stderr.strip():
    print("STDERR:", r.stderr.strip()[-250:])
print("rc:", r.returncode)

print("\n无数据测试:")
w2 = ee._build_wrapper("print('NONE_DF:', df)\n", tempfile.mkdtemp(),
                       os.path.join(tempfile.mkdtemp(), "c"), False, data_table=None)
rp2 = os.path.join(tempfile.mkdtemp(), "_run.py")
open(rp2, "w", encoding="utf-8").write(w2)
r2 = subprocess.run([sys.executable, rp2], capture_output=True, text=True)
print("STDOUT:", r2.stdout.strip(), "| rc:", r2.returncode)

print("\n图表测试:")
charts = ee._auto_generate_charts(os.path.join(tempfile.mkdtemp(), "ch"), 123, data_table=dt)
print("图表数:", len(charts), "| 全部存在:", all(os.path.exists(c) for c in charts))
charts0 = ee._auto_generate_charts(os.path.join(tempfile.mkdtemp(), "ch"), 124, data_table=None)
print("无数据时图表数:", len(charts0), "(应为0, 不造假)")

print("\n完成. 回滚: Copy-Item", os.path.basename(BAK), "experiment_engine.py")
